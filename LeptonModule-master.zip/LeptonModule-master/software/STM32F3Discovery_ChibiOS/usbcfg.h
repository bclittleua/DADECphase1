#ifndef _USBCFG_H_
#define _USBCFG_H_

extern const USBConfig usbcfg;
extern SerialUSBConfig serusbcfg;

#endif  /* _USBCFG_H_ */
