#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define MAIN_DIALOG                             103
#define IDR_ACCELERATOR                         108
#define IDR_MAINMENU                            110
#define IDI_APPICON                             114
#define ID_HELP_ABOUT                           40000
#define ID_FILE_EXIT                            40001
#define IDM_DEBUG_CONSOLE                       40003
#define IDM_PULSE_MODE                          40004
