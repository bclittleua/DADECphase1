int leptopen(void);
int leptget(unsigned short *);
int leptclose(void);
