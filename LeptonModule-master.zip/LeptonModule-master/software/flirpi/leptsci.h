int leptopen(char *dev);
int leptget(unsigned short *);
int leptclose(void);
